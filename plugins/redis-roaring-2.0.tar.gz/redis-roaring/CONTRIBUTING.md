# Contributing

1. Test this project on your side project or on your live application

OR

1. Open a github issue

OR

1. Fork this project
2. Open a pull request
