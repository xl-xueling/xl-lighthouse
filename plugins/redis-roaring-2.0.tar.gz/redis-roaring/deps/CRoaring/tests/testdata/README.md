# test data

These bitmaps were generated from Java : 
https://github.com/RoaringBitmap/RoaringBitmap/blob/master/examples/SerializeToDiskExample.java
